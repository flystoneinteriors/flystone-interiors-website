/*
# Create FlyStone enquiry inbox

1. Purpose
- Stores website enquiries so the FlyStone team can review every request submitted through the public contact form.
- This is a single-company website with no customer sign-in in the first release.

2. New table: `inquiries`
- `id`: unique identifier for the enquiry.
- `created_at`: timestamp for when the enquiry was received.
- `name`: visitor's name.
- `email`: visitor's email address.
- `phone`: visitor's contact number.
- `city`: project city or service location.
- `project_type`: selected project category.
- `message`: free-form project brief.

3. Security
- Row Level Security is enabled.
- The public website may create enquiries and read them only through the future private team workflow; public reads are intentionally denied by the absence of a SELECT policy for anonymous users.
- The four policies are defined separately for clear CRUD behavior. Anonymous INSERT is allowed because the public website has no sign-in screen.

4. Important notes
- This migration does not send email by itself. Email notifications should be connected through a server-side email provider or automation after the inbox is live.
- The table is intentionally limited to enquiry fields and does not store passwords or payment data.
*/

CREATE TABLE IF NOT EXISTS public.inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  city text NOT NULL,
  project_type text NOT NULL,
  message text NOT NULL
);

ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can submit inquiries" ON public.inquiries;
CREATE POLICY "Public can submit inquiries"
  ON public.inquiries FOR INSERT
  TO anon, authenticated
  WITH CHECK (length(trim(name)) BETWEEN 2 AND 120 AND length(trim(email)) BETWEEN 5 AND 180 AND length(trim(phone)) BETWEEN 7 AND 40 AND length(trim(city)) BETWEEN 2 AND 100 AND length(trim(project_type)) BETWEEN 2 AND 80 AND length(trim(message)) BETWEEN 10 AND 2000);

DROP POLICY IF EXISTS "Public cannot read inquiries" ON public.inquiries;
CREATE POLICY "Public cannot read inquiries"
  ON public.inquiries FOR SELECT
  TO anon, authenticated
  USING (false);

DROP POLICY IF EXISTS "Public cannot update inquiries" ON public.inquiries;
CREATE POLICY "Public cannot update inquiries"
  ON public.inquiries FOR UPDATE
  TO anon, authenticated
  USING (false)
  WITH CHECK (false);

DROP POLICY IF EXISTS "Public cannot delete inquiries" ON public.inquiries;
CREATE POLICY "Public cannot delete inquiries"
  ON public.inquiries FOR DELETE
  TO anon, authenticated
  USING (false);

CREATE INDEX IF NOT EXISTS inquiries_created_at_idx ON public.inquiries (created_at DESC);
