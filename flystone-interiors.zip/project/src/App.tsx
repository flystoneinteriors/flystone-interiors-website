import { FormEvent, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Clock,
  Facebook,
  Home,
  Instagram,
  Lightbulb,
  Mail,
  MapPin,
  Menu,
  Minus,
  Phone,
  Play,
  Plus,
  Quote,
  Ruler,
  ShieldCheck,
  Sparkles,
  Sofa,
  Tv,
  Users,
  X,
  Youtube,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

const photos = {
  hero: 'https://images.pexels.com/photos/28853362/pexels-photo-28853362.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  living: 'https://images.pexels.com/photos/34688219/pexels-photo-34688219.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  kitchen: 'https://images.pexels.com/photos/7031211/pexels-photo-7031211.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bedroom: 'https://images.pexels.com/photos/11085646/pexels-photo-11085646.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  dining: 'https://images.pexels.com/photos/6908357/pexels-photo-6908357.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bathroom: 'https://images.pexels.com/photos/6587893/pexels-photo-6587893.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  kids: 'https://images.pexels.com/photos/6670652/pexels-photo-6670652.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  office: 'https://images.pexels.com/photos/13075330/pexels-photo-13075330.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ceiling: 'https://images.pexels.com/photos/30644177/pexels-photo-30644177.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  sofa: 'https://images.pexels.com/photos/8135275/pexels-photo-8135275.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
};

const services = [
  { number: '01', title: 'Modular kitchens', icon: 'kitchen', text: 'Purposeful kitchens with beautiful finishes, intelligent storage, and a place for everyone to gather.', image: photos.kitchen },
  { number: '02', title: 'Living spaces', icon: 'sofa', text: 'Layered, welcoming rooms designed around how your family actually lives, relaxes, and celebrates.', image: photos.living },
  { number: '03', title: 'Bedrooms & wardrobes', icon: 'bed', text: 'Calm personal spaces with custom wardrobes, tactile materials, and thoughtful everyday details.', image: photos.bedroom },
  { number: '04', title: 'Bathrooms', icon: 'bath', text: 'Spa-like bathrooms in stone and marble, where every fitting and finish is considered.', image: photos.bathroom },
  { number: '05', title: 'Kids rooms', icon: 'kids', text: 'Playful, safe, and adaptable rooms that grow with your children and their imagination.', image: photos.kids },
  { number: '06', title: 'False ceiling & lighting', icon: 'light', text: 'Architectural ceilings and layered lighting that shape mood, warmth, and dimension.', image: photos.ceiling },
  { number: '07', title: 'Commercial interiors', icon: 'office', text: 'Workspaces, clinics, and retail environments designed for productivity and brand presence.', image: photos.office },
  { number: '08', title: 'Dining & entertainment', icon: 'dining', text: 'Dining rooms and entertainment walls that bring people together, beautifully and often.', image: photos.dining },
];

const serviceIcons: Record<string, typeof Home> = {
  kitchen: Home, sofa: Sofa, bed: Home, bath: Home, kids: Home, light: Lightbulb, office: Home, dining: Tv,
};

const process = [
  ['01', 'Listen', 'We begin with your lifestyle, your taste, and the way you want to feel at home.'],
  ['02', 'Imagine', 'Our designers translate your brief into a clear visual direction and considered plan.'],
  ['03', 'Create', 'From first drawing to final detail, we manage the journey with care and precision.'],
  ['04', 'Hand over', 'We deliver on time, style every corner, and walk you through your finished space.'],
];

const stats = [
  ['50+', 'Projects delivered'],
  ['5', 'Years of craft'],
  ['3', 'States served'],
  ['100%', 'On-time handover'],
];

const portfolioCategories = ['All', 'Kitchens', 'Living', 'Bedrooms', 'Bathrooms', 'Dining', 'Commercial'];

const portfolio = [
  { src: photos.kitchen, category: 'Kitchens', title: 'Marble island kitchen', place: 'Kondapur, Hyderabad' },
  { src: photos.living, category: 'Living', title: 'Warm contemporary living', place: 'Gachibowli, Hyderabad' },
  { src: photos.bedroom, category: 'Bedrooms', title: 'Serene primary bedroom', place: 'Bengaluru' },
  { src: photos.bathroom, category: 'Bathrooms', title: 'Marble spa bathroom', place: 'Jubilee Hills, Hyderabad' },
  { src: photos.dining, category: 'Dining', title: 'Open-plan dining', place: 'Madhapur, Hyderabad' },
  { src: photos.office, category: 'Commercial', title: 'Home office workspace', place: 'Vizag, Andhra Pradesh' },
  { src: photos.kids, category: 'Bedrooms', title: 'Playful kids room', place: 'Kukatpally, Hyderabad' },
  { src: photos.ceiling, category: 'Living', title: 'Layered ceiling lighting', place: 'Warangal, Telangana' },
];

const testimonials = [
  { quote: 'They understood our family before they touched a wall. Our home finally feels like us.', name: 'Sneha & Arjun', place: 'Kondapur, Hyderabad' },
  { quote: 'The kitchen is the heart of our home now. Every drawer, every shelf, has a reason.', name: 'K. Suneel Kumar', place: 'Gachibowli, Hyderabad' },
  { quote: 'Professional, warm, and on time. They handed over exactly what they promised.', name: 'Dr. Anitha Reddy', place: 'Bengaluru' },
];

const faqs = [
  ['Which cities and states do you serve?', 'We are based in Hyderabad and serve clients across Telangana, Andhra Pradesh, and Karnataka. For larger projects we are happy to discuss travel beyond these regions.'],
  ['Do you offer a free first consultation?', 'Yes. Your first conversation with our studio is complimentary. We will talk through your space, your taste, your timeline, and your budget before any commitment.'],
  ['Can I see examples of your previous work?', 'Absolutely. You can browse a selection of our projects in the portfolio above, and follow our YouTube and Instagram for more. We are happy to share more on request.'],
  ['How long does a full home interior take?', 'A typical full home interior takes 45 to 90 days from design lock to handover, depending on the scope. We will give you a clear timeline after the first site visit.'],
  ['Do you provide a warranty?', 'Yes. Our workmanship comes with a warranty, and we use materials from trusted brands that carry their own manufacturer guarantees. We will walk you through every detail.'],
  ['How do I get started?', 'Simply fill in the enquiry form on this page, or call us directly. We will get back to you within one working day to schedule your first conversation.'],
];

const projectTypes = [
  'Full home interiors',
  'Modular kitchen',
  'Wardrobes & storage',
  'Bedroom design',
  'Bathroom design',
  'False ceiling & lighting',
  'Commercial interiors',
  'Renovation or consultation',
];

const serviceAreas = ['Hyderabad', 'Secunderabad', 'Bengaluru', 'Warangal', 'Vizag', 'Vijayawada', 'Guntur', 'Mysuru', 'Other'];

type FormValues = {
  name: string;
  email: string;
  phone: string;
  city: string;
  project_type: string;
  message: string;
};

const initialForm: FormValues = { name: '', email: '', phone: '', city: 'Hyderabad', project_type: 'Full home interiors', message: '' };

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeService, setActiveService] = useState(0);
  const [portfolioFilter, setPortfolioFilter] = useState('All');
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [form, setForm] = useState<FormValues>(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  const updateField = (field: keyof FormValues, value: string) => setForm((current) => ({ ...current, [field]: value }));

  const submitInquiry = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setFormError('');
    const { error } = await supabase.from('inquiries').insert(form);
    if (error) {
      setFormError('We could not send your enquiry right now. Please call us directly and we will be happy to help.');
      setSubmitting(false);
      return;
    }
    setSubmitted(true);
    setForm(initialForm);
    setSubmitting(false);
  };

  const closeMenu = () => setMenuOpen(false);
  const filteredPortfolio = portfolioFilter === 'All' ? portfolio : portfolio.filter((item) => item.category === portfolioFilter);
  const ActiveIcon = serviceIcons[services[activeService].icon] ?? Home;

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="FlyStone Interiors home" onClick={closeMenu}>
          <span className="brand-mark">fsi</span>
          <span className="brand-name"><strong>Fly</strong>Stone <small>INTERIORS</small></span>
        </a>
        <button className="menu-toggle" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        <nav className={menuOpen ? 'main-nav is-open' : 'main-nav'}>
          <a href="#studio" onClick={closeMenu}>Studio</a>
          <a href="#services" onClick={closeMenu}>Services</a>
          <a href="#portfolio" onClick={closeMenu}>Portfolio</a>
          <a href="#approach" onClick={closeMenu}>Approach</a>
          <a href="#faq" onClick={closeMenu}>FAQ</a>
          <a href="#contact" onClick={closeMenu} className="nav-cta">Start a conversation <ArrowUpRight size={16} /></a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span /> Hyderabad · Telangana · Andhra Pradesh · Karnataka</p>
          <h1>Spaces that feel<br /><em>like you.</em></h1>
          <p className="hero-intro">Thoughtful interiors for the life you are building. We create warm, enduring homes with a distinct point of view — from full-home design to a single beautiful room.</p>
          <div className="hero-actions">
            <a className="primary-button" href="#contact">Begin your project <ArrowUpRight size={17} /></a>
            <a className="ghost-button" href="#portfolio">View our work <ArrowRight size={17} /></a>
          </div>
          <div className="hero-note"><Sparkles size={15} /><span>Premium interior design with a human touch<br />Free first consultation · On-time handover</span></div>
        </div>
        <div className="hero-visual">
          <img src={photos.hero} alt="Warm, contemporary living room designed with layered neutrals" />
          <div className="hero-stamp"><span>DESIGNING SPACES</span><i>✦</i><span>CREATING EXPERIENCES</span></div>
          <div className="hero-caption">01 <span>Residence / Hyderabad</span></div>
        </div>
      </section>

      <section className="stats-band">
        {stats.map(([value, label]) => (
          <div className="stat-item" key={label}>
            <span className="stat-value">{value}</span>
            <span className="stat-label">{label}</span>
          </div>
        ))}
      </section>

      <section className="intro section" id="studio">
        <div className="section-label">01 / The studio</div>
        <div className="intro-content">
          <h2>Design is not just<br />what you <em>see.</em></h2>
          <div>
            <p className="lead">It is what you notice, what you remember, and how effortlessly a space works around you.</p>
            <p>At FlyStone Interiors, we bring together architecture, material, and light to create spaces with a quiet confidence. Based in Hyderabad and working across South India, our studio designs homes that are personal, practical, and made to last — whether it is a full home, a single room, or a commercial space.</p>
            <div className="intro-features">
              <span><ShieldCheck size={16} /> Workmanship warranty</span>
              <span><Clock size={16} /> On-time delivery</span>
              <span><Users size={16} /> In-house design team</span>
            </div>
            <a className="text-link dark" href="#approach">Our way of working <ArrowUpRight size={17} /></a>
          </div>
        </div>
      </section>

      <section className="services section" id="services">
        <div className="section-heading"><div><div className="section-label">02 / What we do</div><h2>A better everyday<br /><em>starts at home.</em></h2></div><p>From the first sketch to the final styling, we make the complex feel simple and the ordinary feel considered. Choose any space — we will make it yours.</p></div>
        <div className="service-layout">
          <div className="service-list">{services.map((service, index) => {
            const Icon = serviceIcons[service.icon] ?? Home;
            return (
              <button className={activeService === index ? 'service-item active' : 'service-item'} key={service.number} onClick={() => setActiveService(index)}>
                <span className="service-number">{service.number}</span>
                <span className="service-icon"><Icon size={18} /></span>
                <strong>{service.title}</strong>
                <ChevronDown size={18} />
              </button>
            );
          })}</div>
          <div className="service-feature">
            <img src={services[activeService].image} alt={services[activeService].title} />
            <div className="service-overlay">
              <div className="service-overlay-text">
                <span className="service-overlay-icon"><ActiveIcon size={20} /></span>
                <p>{services[activeService].text}</p>
              </div>
              <a href="#contact" aria-label={`Enquire about ${services[activeService].title}`}><ArrowUpRight size={23} /></a>
            </div>
          </div>
        </div>
      </section>

      <section className="statement"><div className="statement-inner"><Quote size={26} /><p>“The best rooms have something to say about the people who live in them.”</p><span>— FlyStone design principle</span></div></section>

      <section className="portfolio section" id="portfolio">
        <div className="section-heading"><div><div className="section-label">03 / Portfolio</div><h2>Made for living<br /><em>beautifully.</em></h2></div><a className="text-link dark" href="https://www.instagram.com/flystoneinteriors" target="_blank" rel="noreferrer">More on Instagram <Instagram size={17} /></a></div>
        <div className="portfolio-filters">
          {portfolioCategories.map((category) => (
            <button key={category} className={portfolioFilter === category ? 'filter-chip active' : 'filter-chip'} onClick={() => setPortfolioFilter(category)}>{category}</button>
          ))}
        </div>
        <div className="portfolio-grid">
          {filteredPortfolio.map((item) => (
            <div className="portfolio-card" key={item.title}>
              <img src={item.src} alt={item.title} loading="lazy" />
              <div className="portfolio-info">
                <span>{item.category}</span>
                <h3>{item.title}</h3>
                <p><MapPin size={13} /> {item.place}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="approach section" id="approach">
        <div className="section-label">04 / Our approach</div>
        <div className="approach-grid">
          <div>
            <h2>Considered<br /><em>from the start.</em></h2>
            <div className="approach-symbol"><Ruler size={27} /><span>From vision to reality, beautifully.</span></div>
          </div>
          <div className="process-list">
            {process.map(([number, title, text]) => (
              <div className="process-item" key={number}>
                <span>{number}</span>
                <div><h3>{title}</h3><p>{text}</p></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials section">
        <div className="section-label">05 / Client stories</div>
        <h2 className="testimonials-heading">Homes our clients<br /><em>love to live in.</em></h2>
        <div className="testimonials-grid">
          {testimonials.map((testimonial) => (
            <div className="testimonial-card" key={testimonial.name}>
              <Quote size={22} />
              <p>{testimonial.quote}</p>
              <div className="testimonial-author"><strong>{testimonial.name}</strong><span>{testimonial.place}</span></div>
            </div>
          ))}
        </div>
      </section>

      <section className="faq section" id="faq">
        <div className="faq-layout">
          <div className="faq-intro">
            <div className="section-label">06 / Questions</div>
            <h2>Good to <em>know.</em></h2>
            <p>Still curious? We are happy to answer anything on a call.</p>
            <a className="text-link dark" href="tel:+919908732206"><Phone size={16} /> Call the studio</a>
          </div>
          <div className="faq-list">
            {faqs.map(([question, answer], index) => (
              <div className={openFaq === index ? 'faq-item open' : 'faq-item'} key={question}>
                <button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-label={`Toggle ${question}`}>
                  <span>{question}</span>
                  {openFaq === index ? <Minus size={18} /> : <Plus size={18} />}
                </button>
                <div className="faq-answer"><p>{answer}</p></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="contact section" id="contact">
        <div className="contact-intro">
          <div className="section-label">07 / Let's talk</div>
          <h2>Your space<br />starts <em>here.</em></h2>
          <p>Tell us a little about your project. We will get back to you within one working day.</p>
          <div className="contact-details">
            <a href="tel:+919962458144"><Phone size={17} /> 99624 58144</a>
            <a href="tel:+919908732206"><Phone size={17} /> 99087 32206</a>
            <a href="tel:+914045175919"><Phone size={17} /> 040 45175919</a>
            <a href="mailto:info@flystoneinteriors.com"><Mail size={17} /> info@flystoneinteriors.com</a>
            <a href="mailto:flystoneinteriors@gmail.com"><Mail size={17} /> flystoneinteriors@gmail.com</a>
            <span className="contact-address"><MapPin size={17} /> WeWork, Krishe Emerald, Kondapur,<br /> Hyderabad – 500081</span>
          </div>
          <div className="contact-social">
            <a href="https://youtube.com/@flystoneinteriors?si=a5jMoUxCQW7ZdsVh" target="_blank" rel="noreferrer" aria-label="YouTube"><Youtube size={18} /></a>
            <a href="https://www.instagram.com/flystoneinteriors" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={18} /></a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook"><Facebook size={18} /></a>
          </div>
        </div>
        <div className="contact-form-wrap">
          {submitted ? (
            <div className="success-state">
              <span><Check size={25} /></span>
              <h3>Thank you for reaching out.</h3>
              <p>Your enquiry is with our studio. We will be in touch within one working day.</p>
              <button onClick={() => setSubmitted(false)}>Send another enquiry</button>
            </div>
          ) : (
            <form onSubmit={submitInquiry}>
              <div className="form-row">
                <label>Your name<input required value={form.name} onChange={(event) => updateField('name', event.target.value)} placeholder="Your full name" /></label>
                <label>Email address<input required type="email" value={form.email} onChange={(event) => updateField('email', event.target.value)} placeholder="you@example.com" /></label>
              </div>
              <div className="form-row">
                <label>Phone number<input required value={form.phone} onChange={(event) => updateField('phone', event.target.value)} placeholder="Your best contact number" /></label>
                <label>Project city<select required value={form.city} onChange={(event) => updateField('city', event.target.value)}>
                  {serviceAreas.map((area) => <option key={area} value={area}>{area}</option>)}
                </select></label>
              </div>
              <label>What can we help with?
                <select value={form.project_type} onChange={(event) => updateField('project_type', event.target.value)}>
                  {projectTypes.map((type) => <option key={type} value={type}>{type}</option>)}
                </select>
              </label>
              <label>Tell us about your project<textarea required rows={4} value={form.message} onChange={(event) => updateField('message', event.target.value)} placeholder="A few words about your space, timeline, budget, or ideas..." /></label>
              {formError && <p className="form-error">{formError}</p>}
              <button className="submit-button" disabled={submitting}>{submitting ? 'Sending...' : 'Send enquiry'} <ArrowUpRight size={18} /></button>
              <p className="form-footnote">By submitting, you agree to be contacted by FlyStone Interiors about your project.</p>
            </form>
          )}
        </div>
      </section>

      <footer>
        <div className="footer-top">
          <a className="brand" href="#top"><span className="brand-mark">fsi</span><span className="brand-name"><strong>Fly</strong>Stone <small>INTERIORS</small></span></a>
          <p>Designing spaces.<br /><em>Creating experiences.</em></p>
          <div className="footer-social">
            <a href="https://youtube.com/@flystoneinteriors?si=a5jMoUxCQW7ZdsVh" target="_blank" rel="noreferrer" aria-label="YouTube"><Youtube size={19} /></a>
            <a href="https://www.instagram.com/flystoneinteriors" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={19} /></a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook"><Facebook size={19} /></a>
          </div>
        </div>
        <div className="footer-columns">
          <div className="footer-col">
            <h4>Services</h4>
            <a href="#services">Modular kitchens</a>
            <a href="#services">Living spaces</a>
            <a href="#services">Bedrooms & wardrobes</a>
            <a href="#services">Bathrooms</a>
            <a href="#services">False ceiling & lighting</a>
            <a href="#services">Commercial interiors</a>
          </div>
          <div className="footer-col">
            <h4>Company</h4>
            <a href="#studio">Our studio</a>
            <a href="#approach">Our approach</a>
            <a href="#portfolio">Portfolio</a>
            <a href="#faq">FAQ</a>
            <a href="#contact">Contact</a>
          </div>
          <div className="footer-col">
            <h4>Get in touch</h4>
            <a href="tel:+919962458144">99624 58144</a>
            <a href="tel:+919908732206">99087 32206</a>
            <a href="tel:+914045175919">040 45175919</a>
            <a href="mailto:info@flystoneinteriors.com">info@flystoneinteriors.com</a>
            <span>WeWork, Krishe Emerald,<br />Kondapur, Hyderabad – 500081</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 FlyStone Interiors</span>
          <span>Hyderabad · Telangana · Andhra Pradesh · Karnataka</span>
          <a href="mailto:flystoneinteriors@gmail.com">flystoneinteriors@gmail.com</a>
        </div>
      </footer>

      <a className="floating-call" href="tel:+919908732206"><Phone size={18} /> <span>Call the studio</span></a>
      <a className="floating-play" href="https://youtube.com/@flystoneinteriors?si=a5jMoUxCQW7ZdsVh" target="_blank" rel="noreferrer" aria-label="Watch FlyStone on YouTube"><Play size={16} fill="currentColor" /></a>
    </main>
  );
}

export default App;
